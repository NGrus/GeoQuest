<?php 
   

    function qgonzalo_data() {
        return array(
            'introduction' => qgonzalo_introductionData(),
            "questions" => qgonzalo_questionData(),
            "report" => qgonzalo_reportData()
        );
    }
        
    function qgonzalo_introductionData() {
        return array(
            'title' => "My First Quiz",
            'description' => "Just do it ...",
            'imageURL' => "/images/bild.jpg",
            'nextAction' => 'question.php',
            'questionID' => 'q0'
        );
    }


    function qgonzalo_questionData() {
        return array(
            "q0" => qgonzalo_q0(),
            "q1" => qgonzalo_q1(),
            "q2" => qgonzalo_q2(),
            "q3" => qgonzalo_q3()
        );
    }


    function qgonzalo_q0() {
        return array(
            "text" => "What is the capital of Peru",
            "answers" => array(
                array("Lima", 1),
                array("Piura", 0),
                array("La Libertad", 0),
                array("Cusco", 0)
            ),
            "nextAction" => "question.php",
            "questionID" => "q1"
        );
    }

    function qgonzalo_q1() {
        return array(
            "text" => "What is the biggest River in the world",
            "answers" => array(
                array("Amazonas" => 1),
                array("Sena" => 0),
                array("Aasd" => 0),
                array("lolol" => 0)
            ),
            "nextAction" => "question.php",
            "questionID" => "q2"
        );
    }

    function qgonzalo_q2() {
        return array(
            "text" => "What is the highest mountain in the world",
            "answers" => array(
                array("Everest" => 1),
                array("Matterhorn" => 0),
                array("Aasd" => 0),
                array("lolol" => 0)
            ),
            "nextAction" => "question.php",
            "questionID" => "q3"
        );
    }

    function qgonzalo_q3() {
        return array(
            "text" => "How old are you?",
            "answers" => array(
                array("12" => 1),
                array("11" => 0),
                array("2" => 0),
                array("5" => 0)
            ),
            "nextAction" => "question.php"
        );
    }
    
    function qgonzalo_reportData() {
        return array (
            "title" => "Congraty",
            "greeting" => "You did great"
        );
    }
    
    
    

    
    
    
    
?>
