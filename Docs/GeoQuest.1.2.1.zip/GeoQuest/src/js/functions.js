/*var form = document.getElementById("form1");
function handleForm(event) { event.preventDefault(); } 
form.addEventListener('submit', handleForm);

var form = document.getElementById("form2");
function handleForm(event) { event.preventDefault(); } 
form.addEventListener('submit', handleForm);

var form = document.getElementById("form3");
function handleForm(event) { event.preventDefault(); } 
form.addEventListener('submit', handleForm);

var score = 0;

function add(){
    score++;
    //document.getElementById(a1).innerHTML = score;
    console.log();
}*/