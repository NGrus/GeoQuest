function nextq(){
    document.getElementById("q1").style.visibility = "hidden";
    document.getElementById("q2").style.visibility = "visible";
  }
  
  function nextq2(){
    document.getElementById("q2").style.visibility = "hidden";
    document.getElementById("q3").style.visibility = "visible";
  }
  
  function nextq3(){
    document.getElementById("q3").style.visibility = "hidden";
    document.getElementById("endgame").style.visibility = "visible";
  }
