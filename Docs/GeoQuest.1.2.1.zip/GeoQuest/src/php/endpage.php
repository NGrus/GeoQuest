<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="/build/css/style.css">
</head>
<body>
<?php 

set_include_path($_SERVER['DOCUMENT_ROOT'] . '/php');

include "gonzalo-data.php";

session_start();

$quizData = qgonzalo_data();

if (isset($_POST['questionID'])) {
    $questionID = $_POST['questionID'];
    $pageData = $quizData['questions'][$questionID];
}

if (!isset($pageData)) {
    echo 'Question data for questionID="' . $questionID . '" not available.';
    exit;
}

$SESSION["achievedPoints"] = 0;

$SESSION["achievedPoints"] = $_SESSION["achievedPoints"] + $_POST["radio"];

?>
    

    <div class="bgimg-1">
        <div class="caption">
            <span class="border">
            <?php
                echo '<p>You have answered ' . $_SESSION['achievedPoints'] . ' question(s) correctly.</p>';
            ?></span>
        </div>
    </div>
</body>
</html>