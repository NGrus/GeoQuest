<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="build/css/bs5.css">
    <link rel="stylesheet" href="/build/css/style.css">
    
</head>
<body>

<?php echo $_POST["username"]; ?>

<div class="container">
    <div id="home" class="">
         <h1>Enter your name</h1>
        <div class="user-container">
        <form action="categories.php" method="request">
         <input type="text" name="username" class="user-name">
         <input type="submit" class="submit-btn" value="Play!">
         </form>
         </div>
     </div>
     </div>
     
</body>
</html>