<?php 
    set_include_path($_SERVER['DOCUMENT_ROOT'] . '/gonzalo_quiz');
    
    include "gonzalo-data.php";

    
    
    session_start();

    $quizData = qgonzalo_data();
    echo $quizData;
    $pageData = $quizData['introduction'];
    echo $pageData;
    echo $pageData['questionID'];
    

    $SESSION["achievedPoints"] = 0;

   
?>


<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="/css/main.css">
</head>

<body>
    <div class="bgimg-1">
        <div class="caption">
            <span class="border">
            <?php
                echo $pageData['title']; 
            ?></span>
            <form action="<?php echo $pageData['nextAction']; ?>" method="post">
                <input type="hidden" name="questionID" 
                       value="<?php echo $pageData['questionID']; ?>">
                <input type="submit" value="START">
            </form>
        </div>  
    </div>

    <!--  -->
</body>

</html>