<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="/build/css/style.css">
</head>
<body>


    <div class="category-container">
    <h1 class="player-name">Select game mode <?php echo $_REQUEST["username"]; ?>!</h1>
    <a href="question.php" class="cat-btn-1">Standard</a>
    <a href="#" class="cat-btn-2">Pictures</a>
    </div>


</body>
</html>