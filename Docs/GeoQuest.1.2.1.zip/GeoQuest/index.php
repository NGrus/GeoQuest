<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="/build/css/style.css">
</head>
<body>
    
<div class="container">
    
   <div id="home" class="">
        <h1> Lets play Geo Quest!</h1>
        <a href="/src/php/categories.php" class="play-btn">Play Geo Quest!</a>
        <a href="#" class="highscore-btn">High Scores</a>
    
    </div>
    </div>
</body>
</html>